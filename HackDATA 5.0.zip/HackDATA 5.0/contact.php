<?php
	include "connection.php";
	$mpage="contact";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Team Weirdozz</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.checked {
    color: orange;
}
</style>
  </head>
  <body>
    <?php include "dynamicPage/logo.php" ?> <!-- End site branding area -->
    
    <?php include "dynamicPage/menu.php" ?> <!-- End mainmenu area -->
    
    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>Contact</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br><br>
    <div class="container">
    <div>
    <h1>CONTACT FORM</h1>
    
    <div class="col-md-8">
                    <div class="product-content-right">
                        <form name="f1" method="post" action="">
                        <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                <label class="" for="billing_first_name">Name: <abbr title="required" class="required"></abbr>
                                                </label><br>
                                                <input style="width:400px;" type="text" value="" placeholder="" id="billing_first_name" name="name" class="input-text ">
                                            </p><BR>
                                            <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                <label class="" for="billing_first_name">E-Mail: <abbr title="required" class="required"></abbr>
                                                </label><br>
                                                <input style="width:400px;" type="email" value="" placeholder="" id="billing_first_name" name="email" class="input-text ">
                                            </p><BR>
                                            <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                <label class="" for="billing_first_name">Contact No.: <abbr title="required" class="required"></abbr>
                                                </label><br>
                                                <input style="width:400px;" type="text" value="" placeholder="" id="billing_first_name" name="contact" class="input-text ">
                                            </p><BR>
                                            <p>
                                                <label>Feedback: 
                                                </label><br>
                                                <textarea style="width:400px;" name="feedback"></textarea>
                                            </p><BR>
                                             <input type="submit" value="Submit" name="submit">
                        </form><BR><BR><BR><BR>                      
                    </div>   
                    </div>                 
                
                <div>
                <h3>
                <?php

		
		
				$query="SELECT *FROM `managecontact`";
				$exQuery=mysqli_query($cn,$query);
				$row=mysqli_fetch_array($exQuery);
				$details=$row['details'];
				?>
                <?php
				
				echo $details;
				?>
                
					<br><br>
                
                     </div>  </h3>                 
                </div>
                </div>
                </div>
                
                <?php
					if(isset($_POST['submit']))
					{
						$name=$_POST['name'];
						$email=$_POST['email'];
						$contact=$_POST['contact'];
						$feedback=$_POST['feedback'];
						$yas="INSERT INTO `contact form`(`name`,`email`,`contact`,`feedback`)VALUES('".$name."','".$email."','".$contact."','".$feedback."')";
														$hvi=mysqli_query($cn,$yas);
					
					
					?>
                    <script>
							alert("Feedback Submited!!!");
							window.location.href="contact.php";
					</script>
                    <?php
					}
					?>
                    <br><br><br>
    <?php include "dynamicPage/footer1.php"; ?>
    <?php include "dynamicPage/footer2.php"; ?>
   
    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="js/main.js"></script>
  </body>
</html>