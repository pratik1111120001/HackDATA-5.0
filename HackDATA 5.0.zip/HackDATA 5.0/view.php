<?php
	include "connection.php";
	$mpage="view";
?>
<!DOCTYPE html>
<!--
	ustora by freshdesignweb.com
	Twitter: https://twitter.com/freshdesignweb
	URL: https://www.freshdesignweb.com/ustora/
-->
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Team Weirdozzz</title>
    
    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<style>
.checked {
    color: orange;
}
</style>
  </head>
  <body>
    
    <?php include "dynamicPage/logo.php" ?> <!-- End site branding area -->
    
    <?php include "dynamicPage/menu.php" ?> <!-- End mainmenu area -->
    
    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>View List of All Diseases</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br><br>
    <div class="container">
    <br><br>
    <div class="cart_totals" >

    <table >
    <thead>
    	<tr>
        <th >Diseases Name</th>
            <th >Symptoms</th>
            <th >Prevention	</th>
            <th >Cures</th>
        </tr>
    </thead>
            <tbody>
            <?php
            if(isset($_GET['page']))
            {
                $page=$_GET['page'];
            }
            else
            {
                $page=1;
            }
            $startPage=($page-1)*3;
		
		$x="SELECT COUNT(id) FROM `disease`";
		$y=mysqli_query($cn,$x);
		$row=mysqli_fetch_array($y);
		$totalPages=ceil($row[0]/3);
			
	$query="SELECT *FROM `disease` ORDER BY `name` LIMIT $startPage,3";
	$exQuery=mysqli_query($cn,$query);
	echo "<tr>";
	$cou=0;
	while($row=mysqli_fetch_array($exQuery))
	{
		$id=$row['id'];
		$name=$row['name'];
		$symptoms=$row['symptoms'];
		$prevention=$row['prevention'];
		$cures=$row['cures'];
			echo "<tr>";
				echo "<td >".$name."</td>";
				echo "<td >".$symptoms."</td>";
				echo "<td >".$prevention."</td>";
				echo "<td >".$cures."</td>";
			echo "</tr>";
	}
	echo "</tr>";
?>
    </tbody>
</table>   
<div class="row">
                <div class="col-md-12">
                    <div class="product-pagination text-center">
                        <nav>
                          <ul class="pagination">
                            <li>
                              <a href="view.php?page=<?php 
                              if(isset($_GET['page']))
                              {
                                  $page=$_GET['page'];
                                  if($page>1) $page=$page-1;
                              }
                              else
                              {
                                  $page=1;
                              }
                              echo $page;
                              ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                              </a>
                            </li>
                                <?php
                                    for($i=1;$i<=$totalPages;$i++)
                                    {
                                ?>                           
                                    <li><a href="view.php?page=<?php echo $i ?>"><?php echo $i ?></a></li>
                                <?php
                                    }
                                ?>
                           <li>
                              <a href="view.php?page=<?php 
                              if(isset($_GET['page']))
                              {
                                  $page=$_GET['page'];
                                  if($page<$totalPages) $page=$page+1;
                              }
                              else
                              {
                                  $page=2;
                              }
                              echo $page;
                              ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                              </a>
                            </li>
                          </ul>
                        </nav>                        
                    </div>
                </div>
            </div>  
</div>   
	</div><br><br><br>
    <?php include "dynamicPage/footer1.php"; ?>
    <?php include "dynamicPage/footer2.php"; ?>
   
    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="js/main.js"></script>
  </body>
</html>