<?php
	session_start();
	if(!isset($_SESSION['admin']))
	{
		?>
        	<script>
				window.location.href="login.php";
			</script>
        <?php
	}
	include "connection.php";
    $mpage="contact";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<!-- jQuery file -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.tabify.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var $ = jQuery.noConflict();
$(function() {
$('#tabsmenu').tabify();
$(".toggle_container").hide(); 
$(".trigger").click(function(){
	$(this).toggleClass("active").next().slideToggle("slow");
	return false;
});
});
</script>

<script src="ckeditor/ckeditor.js"></script>
</head>
<body>
<?php
		$query="SELECT *FROM `managecontact`";
		$exQuery=mysqli_query($cn,$query);
		$row=mysqli_fetch_array($exQuery);
		$Details=$row['details'];
			
?>
<div id="panelwrap">
	<div class="header">
    <?php include "dynamicPage/logo.php" ?>
    <?php include "dynamicPage/logout.php" ?>
    <?php include "dynamicPage/menu.php" ?>
    </div>
    <div class="submenu">
    <ul>
    </ul>
    </div>            
    <div class="center_content">
    <div id="right_wrap">
    <div id="right_content">             
    <h2>Manage Contact</h2>
    <ul id="tabsmenu" class="tabsmenu">
        <li class="active"><a href="#tab1">Contact Details</a></li>
    </ul>
    <div id="tab1" class="tabcontent">
   <form name="f1" method="post" action="" enctype="multipart/form-data">  
        <div class="form">   
        <div class="form_row">
            <label>Details: <br /></label>
            </div>
            <div class="form_row">            
            <textarea name="desc"  class="ckeditor" value="<?php echo $Details ?>" ><?php echo $Details ?></textarea>
            </div>
            <div class="form_row">
            <input name="submit" type="submit" class="form_submit" value="Update"/>
            </div> 
            <div class="clear"></div>
        </div>
    </div>
    </form>
     <?php
	if(isset($_POST['submit']))
	{
		$Details=$_POST['desc'];		
		
			$query="UPDATE `managecontact` SET `details`='".$Details."'";			
		
		$exQuery=mysqli_query($cn,$query);
			?>
        	<script>
				alert("Contact Updated");
				window.location.href="manageContact.php";
			</script>
        <?php
		
	}
?>
</div>
     </div><!-- end of right content-->              
    <div class="clear"></div>
    </div> <!--end of center_content-->
    <?php include "dynamicPage/footer.php" ?>
</div>	
</body>
</html>