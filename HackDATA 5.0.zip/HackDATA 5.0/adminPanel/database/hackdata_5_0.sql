-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2021 at 09:01 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hackdata 5.0`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin login`
--

CREATE TABLE `admin login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin login`
--

INSERT INTO `admin login` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `contact form`
--

CREATE TABLE `contact form` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `contact` int(10) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `disease`
--

CREATE TABLE `disease` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `symptoms` text NOT NULL,
  `prevention` text NOT NULL,
  `cures` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `disease`
--

INSERT INTO `disease` (`id`, `name`, `symptoms`, `prevention`, `cures`) VALUES
(4, 'Malaria', '<ul>\r\n	<li>Fever&nbsp;and Flu-like Illness</li>\r\n	<li>Shaking Chills</li>\r\n	<li>Headache</li>\r\n	<li>Muscle Aches</li>\r\n	<li>Tiredness</li>\r\n	<li>Nausea</li>\r\n	<li>Vomiting</li>\r\n	<li>Diarrhea</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Make sure the windows and doors of your room are covered with a screen/mesh. Make sure the mesh has no holes through which mosquitoes can enter.&nbsp;</li>\r\n	<li>Kala HIT can instantly kill even hidden mosquitoes. It reaches every nook and corner of the room and eliminates these dangerous pests, keeping you and your family safe. So, before going to sleep, spray it in your bedroom to kill any lingering mosquitoes.&nbsp;</li>\r\n	<li>Wear long pants, long sleeves, and thick and high socks to dissuade mosquitoes. It&rsquo;s claimed that mosquitoes find light-coloured clothes less attractive, so try to wear such colours.&nbsp;</li>\r\n	<li>If your room isn&rsquo;t air-conditioned, keep the fan switched on. The circulating air seems to deter mosquitoes to an extent.&nbsp;</li>\r\n	<li>Mosquitoes thrive in areas with stagnant water, so ensure there is none around your home or the place you are visiting. In general, stay away from stagnant water.&nbsp;</li>\r\n	<li>Avoid travelling to places where malaria outbreak has occurred.&nbsp;Take necessary&nbsp;precaution for Malaria. Do not visit mosquito-infested areas like open ponds, polluted rivers and waste-filled water resources.&nbsp;</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Treatment of uncomplicated&nbsp;<em>p. falciparum</em>&nbsp;malaria</li>\r\n	<li>Treatment of uncomplicated malaria caused by&nbsp;<em>p. vivax</em></li>\r\n	<li>Treatment of severe malaria</li>\r\n	<li>Mass drug administration</li>\r\n</ul>\r\n'),
(10, 'Diabetes', '<ul>\r\n	<li>Urinate (pee) a lot, often at night.</li>\r\n	<li>Are very thirsty.</li>\r\n	<li>Lose weight without trying.</li>\r\n	<li>Are very hungry.</li>\r\n	<li>Have&nbsp;blurry vision.</li>\r\n	<li>Have numb or tingling hands or feet.</li>\r\n	<li>Feel very tired.</li>\r\n	<li>Have very dry skin.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Cut Sugar and Refined Carbs From Your Diet</li>\r\n	<li>Work Out Regularly</li>\r\n	<li>Drink Water as Your Primary Beverage</li>\r\n	<li>Lose Weight If You&#39;re Overweight or Obese</li>\r\n	<li>Quit Smoking</li>\r\n	<li>Follow a Very-Low-Carb Diet</li>\r\n	<li>Watch Portion Sizes</li>\r\n	<li>Avoid Sedentary Behaviors.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>There&#39;s no cure yet, but our scientists are working on a ground-breaking weight management study,&nbsp;to help people put their Type 2 diabetes into remission.</li>\r\n	<li>Remission is when blood glucose (or blood&nbsp;sugar) levels are in a normal range again.</li>\r\n	<li>This doesn&#39;t mean diabetes has gone for good.</li>\r\n</ul>\r\n'),
(11, 'Asthma', '<ul>\r\n	<li>wheezing,&nbsp;coughing&nbsp;and&nbsp;chest tightness&nbsp;becoming severe and constant.</li>\r\n	<li>being too breathless to eat, speak or sleep.</li>\r\n	<li>breathing faster.</li>\r\n	<li>a fast heartbeat.</li>\r\n	<li>drowsiness, confusion, exhaustion or dizziness.</li>\r\n	<li>blue lips or fingers.</li>\r\n	<li>fainting.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Follow your&nbsp;asthma&nbsp;action plan.</li>\r\n	<li>Get vaccinated for influenza and pneumonia.</li>\r\n	<li>Identify and avoid&nbsp;asthma&nbsp;triggers.</li>\r\n	<li>Monitor your breathing. </li>\r\n	<li>Identify and treat attacks early.</li>\r\n	<li>Take your medication as prescribed.</li>\r\n	<li>Pay attention to increasing quick-relief inhaler use.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Long-term control&nbsp;medications&nbsp;such as inhaled corticosteroids are the most important&nbsp;medications&nbsp;used to keep asthma under control. ...</li>\r\n	<li>Quick-relief inhalers contain a fast-acting&nbsp;medication&nbsp;such as albuterol.</li>\r\n</ul>\r\n'),
(12, 'Corona', '<ul>\r\n	<li>fever</li>\r\n	<li>dry cough</li>\r\n	<li>tiredness</li>\r\n	<li>difficulty breathing or shortness of breath</li>\r\n	<li>chest pain or pressure</li>\r\n	<li>loss of speech or movement</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Clean your hands often. Use soap and water, or an alcohol-based hand rub.</li>\r\n	<li>Maintain a safe distance from anyone who is coughing or sneezing.</li>\r\n	<li>Wear a mask when physical distancing is not possible.</li>\r\n	<li>Don&rsquo;t touch your eyes, nose or mouth.</li>\r\n	<li>Cover your nose and mouth with your bent elbow or a tissue when you cough or sneeze.</li>\r\n	<li>Stay home if you feel unwell.</li>\r\n	<li>If you have a fever, cough and difficulty breathing, seek medical attention.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Call your health care provider or COVID-19 hotline to find out where and when to get a test.</li>\r\n	<li>Cooperate with contact-tracing procedures to stop the spread of the virus.</li>\r\n	<li>If testing is not available, stay home and away from others for 14 days.</li>\r\n	<li>While you are in quarantine, do not go to work, to school or to public places. Ask someone to bring you supplies.</li>\r\n	<li>Keep at least a 1-metre distance from others, even from your family members.</li>\r\n	<li>Wear a medical mask to protect others, including if/when you need to seek medical care.</li>\r\n	<li>Clean your hands frequently.</li>\r\n	<li>Stay in a separate room from other family members, and if not possible, wear a medical mask.</li>\r\n	<li>Keep the room well-ventilated.</li>\r\n	<li>If you share a room, place beds at least 1 metre apart.</li>\r\n	<li>Monitor yourself for any symptoms for 14 days.</li>\r\n	<li>Call your health care provider immediately if you have any of these danger signs: difficulty breathing, loss of speech or mobility, confusion or chest pain.</li>\r\n	<li>Stay positive by keeping in touch with loved ones by phone or online, and by exercising at home.</li>\r\n</ul>\r\n'),
(13, 'Typhoid', '<ul>\r\n	<li>Weakness.</li>\r\n	<li>Stomach pain.</li>\r\n	<li>Headache.</li>\r\n	<li>Diarrhea or constipation.</li>\r\n	<li>Cough.</li>\r\n	<li>Loss of appetite.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Wash your hands. Frequent hand-washing in hot, soapy water is the best way to control infection.</li>\r\n	<li>Avoid drinking untreated water. Contaminated drinking water is a particular problem in areas where&nbsp;typhoid&nbsp;fever is endemic.</li>\r\n	<li>Avoid raw fruits and vegetables.</li>\r\n	<li>Choose hot foods.</li>\r\n	<li>Know where the doctors are.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>The only effective treatment for typhoid is&nbsp;antibiotics.</li>\r\n	<li>The most commonly used are&nbsp;ciprofloxacin&nbsp;(for non-pregnant adults) and&nbsp;ceftriaxone.</li>\r\n	<li>Other than&nbsp;antibiotics, it is important to rehydrate by drinking adequate&nbsp;water.</li>\r\n	<li>In more severe cases, where the bowel has become perforated,&nbsp;surgery&nbsp;may be required.</li>\r\n</ul>\r\n'),
(14, 'Polio', '<ul>\r\n	<li>Progressive muscle or joint&nbsp;weakness&nbsp;and pain.</li>\r\n	<li>Fatigue.</li>\r\n	<li>Muscle wasting (atrophy)</li>\r\n	<li>Breathing or swallowing problems.</li>\r\n	<li>Sleep-related breathing disorders, such as sleep apnea.</li>\r\n	<li>Decreased tolerance of cold temperatures.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>The most effective way to&nbsp;prevent&nbsp;the disease is getting vaccinated.</li>\r\n	<li>Immunisation against&nbsp;polio&nbsp;is recommended for all children from two to 18 months of age.</li>\r\n	<li>Booster doses should be given to all children up to 12 years of age.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>There is no&nbsp;cure&nbsp;for&nbsp;polio, it can only be prevented.&nbsp;</li>\r\n	<li>Polio vaccine, given multiple times, can protect a child for life.</li>\r\n</ul>\r\n'),
(15, 'Cancer', '<ul>\r\n	<li>Fatigue.</li>\r\n	<li>Lump or area of thickening that can be felt under the skin.</li>\r\n	<li>Weight&nbsp;changes, including unintended loss or gain.</li>\r\n	<li>Skin&nbsp;changes, such as yellowing, darkening or redness of the skin, sores that won&#39;t heal, or&nbsp;changes&nbsp;to existing moles.</li>\r\n	<li>Changes&nbsp;in&nbsp;bowel&nbsp;or bladder habits.</li>\r\n	<li>Persistent cough&nbsp;or trouble breathing.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Don&#39;t use tobacco</li>\r\n	<li>Eat a healthy diet</li>\r\n	<li>Maintain a healthy weight and be physically active</li>\r\n	<li>Protect yourself from the sun</li>\r\n	<li>Get vaccinated</li>\r\n	<li>&nbsp;Avoid risky behaviors</li>\r\n	<li>Get regular medical care</li>\r\n</ul>\r\n', '<ul>\r\n	<li>There are no&nbsp;cures&nbsp;for any kinds of&nbsp;cancer, but there are treatments that may&nbsp;cure&nbsp;you.</li>\r\n	<li>Many people are treated for&nbsp;cancer, live out the rest of their life, and die of other causes.</li>\r\n	<li>Many others are treated for&nbsp;cancer&nbsp;and still die from it, although treatment may give them more time: even years or decades.</li>\r\n</ul>\r\n'),
(16, 'Tuberculosis', '<ul>\r\n	<li>A&nbsp;cough&nbsp;that lasts more than three weeks.</li>\r\n	<li>Loss of appetite and unintentional weight loss.</li>\r\n	<li>Fever.</li>\r\n	<li>Chills.</li>\r\n	<li>Night sweats.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Take all of your medicines as they&#39;re prescribed, until your doctor takes you off them.</li>\r\n	<li>Keep all your doctor appointments.</li>\r\n	<li>Always cover your mouth with a tissue when you cough or sneeze. ...</li>\r\n	<li>Wash your hands after coughing or sneezing.</li>\r\n	<li>Don&#39;t visit other people and don&#39;t invite them to visit you.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>If you have an active TB&nbsp;disease&nbsp;you will probably be treated with a combination of antibacterial&nbsp;medications&nbsp;for a period of six to 12 months.</li>\r\n	<li>The most common treatment for active TB is&nbsp;isoniazid&nbsp;INH in combination with three other&nbsp;drugs&mdash;rifampin,&nbsp;pyrazinamide&nbsp;and&nbsp;ethambutol.</li>\r\n</ul>\r\n'),
(17, 'Coronary Artery Disease (CAD)', '<ul>\r\n	<li>Chest pain (angina). You may feel pressure or tightness in your chest, as if someone were standing on your chest. ...</li>\r\n	<li>Shortness of breath. If your heart can&#39;t pump enough blood to meet your body&#39;s needs, you may develop&nbsp;shortness of breath&nbsp;or extreme fatigue with activity.</li>\r\n	<li>Heart attack.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Lifestyle changes, such as eating a healthier (lower sodium, lower fat) diet, increasing physical activity, reaching a healthy weight, and quitting smoking.</li>\r\n	<li>Medicines to treat risk factors for&nbsp;CAD, such as high cholesterol, high blood pressure, or an irregular heartbeat.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Nitroglycerin tablets, sprays and patches can control chest pain by temporarily dilating your coronary arteries and reducing your heart&#39;s demand for blood.&nbsp;</li>\r\n	<li>Angiotensin-converting enzyme (ACE) inhibitors and&nbsp;angiotensin II receptor blockers&nbsp;(ARBs).</li>\r\n</ul>\r\n'),
(18, 'Ebola', '<ul>\r\n	<li>Fever.</li>\r\n	<li>Aches and pains, such as severe&nbsp;headache, muscle and joint pain, and&nbsp;abdominal (stomach) pain.</li>\r\n	<li>Weakness&nbsp;and&nbsp;fatigue.</li>\r\n	<li>Gastrointestinal symptoms including&nbsp;diarrhea&nbsp;and&nbsp;vomiting.</li>\r\n	<li>Abdominal (stomach) pain.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>The best way to avoid Ebola is to stay away from areas where the virus is common.</li>\r\n	<li>&nbsp;Avoid infected people, their body&nbsp;fluids, and the bodies of anyone who has died from the disease.</li>\r\n	<li>Avoid contact with wild animals, like bats and monkeys, and their meat.</li>\r\n</ul>\r\n', '<ul>\r\n	<li>Inmazeb (atoltivimab, maftivimab, and odesivimab-ebgn), a mixture of three monoclonal antibodies, is the first FDA-approved treatment for Zaire ebolavirus (Ebola&nbsp;virus) infection in adult and pediatric patients.</li>\r\n</ul>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `manageabout`
--

CREATE TABLE `manageabout` (
  `id` int(11) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manageabout`
--

INSERT INTO `manageabout` (`id`, `details`) VALUES
(1, '<p><strong>1.In this Project we have developed a main site and an Admin Panel.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2.The Admin Panel Makes the work easily to insert the data in database(using MySQL)</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3.The Main Site the Collects the Data from the Database.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>4.We developed a Dynamic Webpage by creating different files of header and footer.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>5.So,we just have to include it were required.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>&gt;&gt;Also, it helps us to alter the main file only and changes will reflect wherever it is included.</strong></p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `managecontact`
--

CREATE TABLE `managecontact` (
  `id` int(11) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `managecontact`
--

INSERT INTO `managecontact` (`id`, `details`) VALUES
(1, '<p>For Any Query Contact us :-</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>&nbsp;<a href=\"https://mail.google.com/mail/u/0/#inbox?compose=CllgCJlFmHsrrSjHxmftxwfjGpghpztPBsjgjqdxkzLjnCHbmcqkhNGQNFpdwKPQSbpxxRNmDnV\">pratik111120001@gmail.com</a></li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li><a href=\"https://mail.google.com/mail/u/0/#inbox?compose=DmwnWrRmTWglSFZnHvPGzBPJLpZWgLCnPNRxHrJrsvDLnkscNNXKTRKcbLNFgqlVkgqvMWjrJsDG\">thakkarutsav2501@gmail.com</a></li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li><a href=\"https://mail.google.com/mail/u/0/#inbox?compose=DmwnWslzDPLSRzBwSVCdBxtfQrzchscrGzLDVXZpCHtsXBjXMJrrlwblJsjmFQFFqcNlklqNtCFL\">priyankvara12@gmail.com</a></li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li><a href=\"https://mail.google.com/mail/u/0/#inbox?compose=DmwnWsLWPKspDHpBGCbNnhzHdKlcTlssFDBdPsmvzFSNDJtbKWwtWFwGdmtLDTWlTqljlHmfjXkq\">vaghani.2112@gmail.com</a></li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `managehome`
--

CREATE TABLE `managehome` (
  `id` int(11) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `managehome`
--

INSERT INTO `managehome` (`id`, `details`) VALUES
(1, '<p>Search For The Diseases&nbsp;Name To Get Information About it :-</p>\r\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin login`
--
ALTER TABLE `admin login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact form`
--
ALTER TABLE `contact form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `disease`
--
ALTER TABLE `disease`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manageabout`
--
ALTER TABLE `manageabout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `managecontact`
--
ALTER TABLE `managecontact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `managehome`
--
ALTER TABLE `managehome`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin login`
--
ALTER TABLE `admin login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact form`
--
ALTER TABLE `contact form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `disease`
--
ALTER TABLE `disease`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `manageabout`
--
ALTER TABLE `manageabout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `managecontact`
--
ALTER TABLE `managecontact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `managehome`
--
ALTER TABLE `managehome`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
