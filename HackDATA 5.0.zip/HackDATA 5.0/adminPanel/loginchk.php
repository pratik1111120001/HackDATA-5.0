<?php
	session_start();
	include "connection.php";
	$userName=$_POST['userName'];
	$password=$_POST['password'];
	
	$query="SELECT *FROM `admin login` WHERE `username`='".$userName."' AND `password`='".$password."'";
	$exQuery=mysqli_query($cn,$query);
	
	$row=mysqli_num_rows($exQuery);
	
	$_SESSION['admin']=$userName;
	if($row>0)
	{
		?>
        	<script>
				window.location.href="index.php";
			</script>
        <?php
	}
	else
	{
		?>
        	<script>
				alert("Invalid Username or Password Entered");
				window.location.href="login.php";
			</script>
        <?php
	}
	
?>