<?php
	session_start();
	if(!isset($_SESSION['admin']))
	{
		?>
        	<script>
				window.location.href="login.php";
			</script>
        <?php
	}
	include "connection.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<!-- jQuery file -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.tabify.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var $ = jQuery.noConflict();
$(function() {
$('#tabsmenu').tabify();
$(".toggle_container").hide(); 
$(".trigger").click(function(){
	$(this).toggleClass("active").next().slideToggle("slow");
	return false;
});
});
</script>
</head>
<body>
<div id="panelwrap">
	<div class="header">
    <?php include "dynamicPage/logo.php" ?>
    <?php include "dynamicPage/logout.php" ?>
    <?php include "dynamicPage/menu.php" ?>
    </div>
    <div class="submenu">
    <ul>
    </ul>
    </div>            
    <div class="center_content">
    <div id="right_wrap">
    <div id="right_content">             
    <h2>Manage Diseases</h2>
    <ul id="tabsmenu" class="tabsmenu">
        <li class="active"><a href="#tab1">View Diseases</a></li>
    </ul>
    <br /><br /><br /><br />
    <table id="rounded-corner" cellpadding="10" border="3px">
    <thead>
    	<tr>
        <th >Diseases Name</th>
            <th >Symptoms</th>
            <th >Prevention	</th>
            <th >Cures</th>
        </tr>
    </thead>
            <tbody>
            <?php
			
	$query="SELECT *FROM `disease`";
	$exQuery=mysqli_query($cn,$query);
	echo "<tr>";
	$cou=0;
	while($row=mysqli_fetch_array($exQuery))
	{
		$id=$row['id'];
		$name=$row['name'];
		$symptoms=$row['symptoms'];
		$prevention=$row['prevention'];
		$cures=$row['cures'];
			echo "<tr>";
				echo "<td >".$name."</td>";
				echo "<td >".$symptoms."</td>";
				echo "<td >".$prevention."</td>";
				echo "<td >".$cures."</td>";
			echo "</tr>";
	}
	echo "</tr>";
?>
    </tbody>
</table>                
</div>
     </div><!-- end of right content-->
      <?php include "dynamicPage/Panel.php" ?>             
    <div class="clear"></div>
    </div> <!--end of center_content-->
    <?php include "dynamicPage/footer.php" ?> 
</div>
</body>
</html>