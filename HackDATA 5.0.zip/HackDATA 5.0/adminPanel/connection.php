<?php
	$cn=mysqli_connect("localhost","root","","hackdata 5.0");
?>