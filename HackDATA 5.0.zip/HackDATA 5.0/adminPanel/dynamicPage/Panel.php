<div class="sidebar" id="sidebar">
    <h2>Manage Product</h2>
        <ul>
            <li><a href="manageDiseases.php">Add New Entry</a></li>
            <li><a href="view.php">View Diseases</a></li>
        </ul>
    </div>