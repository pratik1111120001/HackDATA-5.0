<div class="menu">
    <ul>
    <li><a href="index.php" class="selected">Home</a></li>
    <li><a href="manageDiseases.php"  class="selected">Manage Diseases</a></li>
    <li><a href="manageHome.php"  class="selected">Manage Home</a></li>
    <li><a href="manageAbout.php"  class="selected">Manage About</a></li>
    <li><a href="manageContact.php"  class="selected">Manage Contact</a></li>
    </ul>
    </div>