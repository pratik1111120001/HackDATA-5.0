<div class="footer">
The Website is developed by Team Weirdozz <a href="#" target="_blank">Copy Rights 2021</a>
</div>