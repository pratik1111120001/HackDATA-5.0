<div  class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="copyright">
                        <p>&copy; Copy Rights 2021. All Rights Reserved.</p>
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>