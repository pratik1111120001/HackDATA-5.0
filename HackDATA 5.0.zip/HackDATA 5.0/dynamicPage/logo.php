<div class="site-branding-area">
        <div class="container">
            <div class="row">

            <div class="col-sm-6">
                    <div class="logo">
                        <h1>Health Care</h1>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End site branding area -->
    
