<div style="background-color : #1a1a1a; "; class="footer-top-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <h1 style="padding-left: 100px;">Developed By : Team Weirdozzz</h1><br><br>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                <div class="footer-menu">
                        <h2 class="footer-wid-title">Name </h2>
                        <ul>
                            <li>Pratik Thakkar</li>
                            <li>Utsav Thakkar</li>
                            <li>Priyank Vara</li>
                            <li>Savan Vaghani</li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title">Contact No. </h2>
                        <ul>
                            <li>99242 55518</li>
                            <li>91579 10056</li>
                            <li>99797 43432</li>
                            <li>70699 56884</li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                <div class="footer-menu">
                        <h2 class="footer-wid-title">E-mail </h2>
                        <ul>
                            <li>pratik111120001@gmail.com</li>
                            <li>thakkarutsav2501@gmail.com</li>
                            <li>priyankvara12@gmail.com</li>
                            <li>vaghani.2112@gmail.com</li>
                        </ul>                        
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6">
                    <div class="footer-newsletter">
                        <h2 class="footer-wid-title">Support</h2>
                        <p>For any other query enter your E-mail. We will contact You within couple of Hours.</p>
                        <div class="newsletter-form">
                            <form action="#">
                                <input type="email" placeholder="Type your email">
                                <input type="submit" value="Submit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>